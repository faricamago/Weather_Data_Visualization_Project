import numpy as np
class WeatherAnalyzer:
    def __init__(self,List):
        self.list_of_objects = List

    def getMinTemp(self):
        array_of_mintemp = []
        for i in range(len(self.list_of_objects)):
            array_of_mintemp.append(self.list_of_objects[i].minTemperature)
        return np.min(array_of_mintemp)
    
    def getMinTempAnnually(self):
        array_of_mintemp_annual = []
        for j in range(int(self.list_of_objects[0].date.Year),int((self.list_of_objects[len(self.list_of_objects)-1].date.Year)+1)):
            array_of_mintemp = []
            for i in range(len(self.list_of_objects)): 
                if((self.list_of_objects[i].date.Year)==j):
                    array_of_mintemp.append(self.list_of_objects[i].minTemperature)
            array_of_mintemp_annual.append([j,np.min(array_of_mintemp)])
        return array_of_mintemp_annual

    def getMaxTemp(self):
        array_of_maxtemp = []
        for i in range(len(self.list_of_objects)):
            array_of_maxtemp.append(self.list_of_objects[i].maxTemperature)
        return np.max(array_of_maxtemp)

    def getMaxTempAnnually(self):        
        array_of_maxtemp_annual = []
        for j in range(int(self.list_of_objects[0].date.Year),int((self.list_of_objects[len(self.list_of_objects)-1].date.Year)+1)):
            array_of_maxtemp = []
            for i in range(len(self.list_of_objects)): 
                if((self.list_of_objects[i].date.Year)==j):
                    array_of_maxtemp.append(self.list_of_objects[i].maxTemperature)
            array_of_maxtemp_annual.append([j,np.max(array_of_maxtemp)])
        return array_of_maxtemp_annual

    def getAvgSnowFallAnnually(self):        
        array_of_avg_annual = []
        for j in range(int(self.list_of_objects[0].date.Year),int((self.list_of_objects[len(self.list_of_objects)-1].date.Year)+1)):
            array_of_snowfall = []
            for i in range(len(self.list_of_objects)): 
                if((self.list_of_objects[i].date.Year)==j):
                    array_of_snowfall.append(self.list_of_objects[i].snowFall)
            array_of_avg_annual.append([j,np.average(array_of_snowfall)])
        return array_of_avg_annual

    def getAvgTempAnnually(self):        
        array_of_avg_annual = []
        for j in range(int(self.list_of_objects[0].date.Year),int((self.list_of_objects[len(self.list_of_objects)-1].date.Year)+1)):
            array_of_Temp = []
            for i in range(len(self.list_of_objects)): 
                if((self.list_of_objects[i].date.Year)==j):
                    array_of_Temp.append((self.list_of_objects[i].minTemperature+self.list_of_objects[i].maxTemperature)/2)
            array_of_avg_annual.append([j,np.average(array_of_Temp)])
        return array_of_avg_annual