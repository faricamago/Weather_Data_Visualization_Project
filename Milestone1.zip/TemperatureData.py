import Date as d
class TemperatureData:
    def __init__(self,month,year,mintemp,maxtemp,sf):
        self.date = d.Date(month,year)
        self.minTemperature = mintemp
        self.maxTemperature = maxtemp
        self.snowFall = sf
