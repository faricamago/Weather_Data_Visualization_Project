class Date:
    def __init__(self,Month,Year):
        self.Month = Month
        self.Year = Year