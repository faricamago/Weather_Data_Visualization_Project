import numpy as np
import FileIO as F
import Date as D
import TemperatureData as T
import WeatherAnalyzer as W
def main():
    Fileio = F.FileIO("CalgaryWeather.csv")
    datatable  = Fileio.Get()
    no_of_objects = len(datatable[:,0])
    array_of_objects = []
    for i in range(no_of_objects):
        tempdata = T.TemperatureData(datatable[i,1],datatable[i,0],datatable[i,3],datatable[i,2],datatable[i,4])
        array_of_objects.append(tempdata)
    weather = W.WeatherAnalyzer(array_of_objects)

    print("1- Get Minimum Temperature of 1990-2019")
    print("2- Get Maximum Temperature of 1990-2019")
    print("3- Get Minimum Temperature of 1990-2019 Annually")
    print("4- Get Maximum Temperature of 1990-2019 Annually")
    print("5- Get Average Snowfall between 1990-2019 Annually")
    print("6- Get Average Temperature between 1990-2019 Annually")
    user_wants = int(input("Enter your choice!"))
    if(user_wants==1):
        print(weather.getMinTemp())
    elif(user_wants==2):
        print(weather.getMaxTemp())
    elif(user_wants==3):
        i = 0
        array_of_minimumtemp = (weather.getMinTempAnnually())  
        for j in range(int(array_of_objects[0].date.Year),int((array_of_objects[len(array_of_objects)-1].date.Year)+1)):
            print(f"Minimum temperature in the year {array_of_minimumtemp[i][0]} is:",array_of_minimumtemp[i][1])
            i+=1
    elif(user_wants==4):
        i = 0
        array_of_maximumtemp = (weather.getMaxTempAnnually())  
        for j in range(int(array_of_objects[0].date.Year),int((array_of_objects[len(array_of_objects)-1].date.Year)+1)):
            print(f"Maximum temperature in the year {array_of_maximumtemp[i][0]} is:",array_of_maximumtemp[i][1])
            i+=1
    elif(user_wants==5):
        i = 0
        array_of_snow = weather.getAvgSnowFallAnnually() 
        for j in range(int(array_of_objects[0].date.Year),int((array_of_objects[len(array_of_objects)-1].date.Year)+1)):
            print(f"Average snowfall in the year {array_of_snow[i][0]} is:",array_of_snow[i][1])
            i+=1
    elif(user_wants==6):
        i = 0
        array_of_avgtemp = weather.getAvgTempAnnually()
        for j in range(int(array_of_objects[0].date.Year),int((array_of_objects[len(array_of_objects)-1].date.Year)+1)):
            print(f"Average temperature in the year {array_of_avgtemp[i][0]} is:",array_of_avgtemp[i][1])
            i+=1

if __name__== "__main__":
    main()